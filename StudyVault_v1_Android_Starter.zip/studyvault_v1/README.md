# StudyVault v1 — Android starter

StudyVault is an Expo / React Native Android app starter with a Supabase cloud backend.

## Included in v1
- Native Android app foundation (Expo + React Native)
- System-aware light/dark appearance with a manual toggle
- Supabase session persistence
- Google sign-in entry point (provider setup still required)
- Private cloud file uploads
- Per-user resource metadata and row-level security
- Subject field, library list, search, and delete
- Private storage bucket and signed-link generation

## Important setup
This is a starter project, not a published APK. You need a computer with Node.js and Android tooling, plus a Supabase project. Never put a Supabase service-role key in the app. Only use the project's anon/publishable key.

### 1. Install dependencies
```bash
npm install
```

### 2. Create Supabase project
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy the Project URL and anon/publishable key from Project Settings → API.
4. Copy `.env.example` to `.env` and fill in the two values.

### 3. Configure Google sign-in
1. In Supabase Authentication → Providers, enable Google.
2. Configure Google OAuth credentials in Google Cloud Console.
3. Add the Supabase callback URL shown by Supabase to the Google OAuth client.
4. Configure the app's redirect/deep-link URL and allowed redirect URLs in Supabase.
5. Implement the Expo AuthSession browser OAuth flow and deep-link callback before enabling production sign-in.

The current `signIn()` function intentionally displays a setup note rather than pretending OAuth is configured. Google OAuth needs valid client IDs, redirect URIs and provider settings.

### 4. Run the app
```bash
npx expo start
```
Use Expo Go for an early UI preview where supported, or create a development build for native Android testing.

### 5. Build an Android APK
Use EAS Build after configuring an Expo account and Android application identifier:
```bash
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
```
For an installable APK, configure the `preview` profile in `eas.json` with `"android": { "buildType": "apk" }`.

## Known v1 limitations
- Google OAuth needs the setup and callback implementation described above.
- In-app PDF/document preview is not implemented yet.
- File opening currently creates a short-lived signed URL and shows a confirmation; a document viewer is a next-version task.
- Uploads read the selected file into memory; very large files should use a streaming/resumable upload approach.
- No password recovery, account deletion UI, folders, tags, or sharing yet.

## Privacy and security
- The storage bucket is private.
- SQL policies scope database rows and stored files to the authenticated user.
- Use a strong Supabase project password and keep OAuth secrets out of the mobile app.
- Test policies with two separate test accounts before sharing the app.
- Because this app is intended for student resources, do not upload sensitive personal documents.
