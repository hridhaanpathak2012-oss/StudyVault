-- Run this in Supabase SQL Editor.
-- Private metadata table: each user can only see and change their own resources.
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  subject text not null default 'General',
  storage_path text not null unique,
  mime_type text,
  created_at timestamptz not null default now()
);

alter table public.resources enable row level security;

create policy "Users can view their own resources"
on public.resources for select
using (auth.uid() = user_id);

create policy "Users can add their own resources"
on public.resources for insert
with check (auth.uid() = user_id);

create policy "Users can delete their own resources"
on public.resources for delete
using (auth.uid() = user_id);

-- Private bucket. Create it once; if it already exists, check its privacy setting.
insert into storage.buckets (id, name, public)
values ('study-resources', 'study-resources', false)
on conflict (id) do nothing;

create policy "Users can upload into their own folder"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'study-resources'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can read files in their own folder"
on storage.objects for select
to authenticated
using (
  bucket_id = 'study-resources'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can delete files in their own folder"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'study-resources'
  and (storage.foldername(name))[1] = auth.uid()::text
);
