import "react-native-url-polyfill/auto";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator, Alert, FlatList, Pressable, SafeAreaView,
  StatusBar, StyleSheet, Text, TextInput, useColorScheme, View
} from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";

type Resource = {
  id: string; name: string; subject: string; storage_path: string;
  mime_type: string | null; created_at: string;
};

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL ?? "";
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? "";
const supabase: SupabaseClient | null =
  supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey, {
    auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false }
  }) : null;

const palette = {
  light: { bg: "#F5F7FB", card: "#FFFFFF", text: "#172033", muted: "#68748A", line: "#E4E8F0", accent: "#4568D8", soft: "#EAF0FF" },
  dark: { bg: "#101827", card: "#1B2638", text: "#F3F6FC", muted: "#A7B2C5", line: "#2D3A50", accent: "#91ACFF", soft: "#263657" }
};

export default function App() {
  const systemScheme = useColorScheme();
  const [mode, setMode] = useState<"system" | "light" | "dark">("system");
  const dark = mode === "dark" || (mode === "system" && systemScheme === "dark");
  const c = dark ? palette.dark : palette.light;
  const [session, setSession] = useState<any>(null);
  const [resources, setResources] = useState<Resource[]>([]);
  const [subject, setSubject] = useState("General");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [configured, setConfigured] = useState(!!supabase);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) loadResources(data.session.user.id);
      else setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      if (next) loadResources(next.user.id);
      else { setResources([]); setLoading(false); }
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadResources(userId: string) {
    if (!supabase) return;
    setLoading(true);
    const { data, error } = await supabase.from("resources")
      .select("*").eq("user_id", userId).order("created_at", { ascending: false });
    if (error) Alert.alert("Couldn't load library", error.message);
    else setResources((data ?? []) as Resource[]);
    setLoading(false);
  }

  async function signIn() {
    if (!supabase) return;
    Alert.alert(
      "Google sign-in setup",
      "Google OAuth needs to be enabled in your Supabase project and configured with an approved redirect URL. This starter shows the sign-in entry point; finish the provider setup using the README before testing sign-in.",
      [{ text: "OK" }]
    );
  }

  async function upload() {
    if (!supabase || !session) return;
    const picked = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false });
    if (picked.canceled || !picked.assets?.[0]) return;
    const file = picked.assets[0];
    setBusy(true);
    try {
      const base64 = await FileSystem.readAsStringAsync(file.uri, { encoding: FileSystem.EncodingType.Base64 });
      const binary = Uint8Array.from(atob(base64), ch => ch.charCodeAt(0));
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `${session.user.id}/${Date.now()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from("study-resources")
        .upload(path, binary, { contentType: file.mimeType ?? "application/octet-stream", upsert: false });
      if (uploadError) throw uploadError;
      const { error: insertError } = await supabase.from("resources").insert({
        user_id: session.user.id, name: file.name, subject, storage_path: path,
        mime_type: file.mimeType ?? null
      });
      if (insertError) {
        await supabase.storage.from("study-resources").remove([path]);
        throw insertError;
      }
      await loadResources(session.user.id);
      Alert.alert("Uploaded", `${file.name} was added to your library.`);
    } catch (e: any) {
      Alert.alert("Upload failed", e?.message ?? "Please try again.");
    } finally { setBusy(false); }
  }

  async function openResource(item: Resource) {
    if (!supabase) return;
    const { data, error } = await supabase.storage.from("study-resources")
      .createSignedUrl(item.storage_path, 60);
    if (error || !data?.signedUrl) Alert.alert("Couldn't open file", error?.message ?? "No download link.");
    else Alert.alert("Resource ready", "A temporary secure file link was created. Add a document viewer in the next version to open files inside the app.");
  }

  async function deleteResource(item: Resource) {
    if (!supabase) return;
    Alert.alert("Delete resource?", `Remove "${item.name}" from your library?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
        const { error } = await supabase!.from("resources").delete().eq("id", item.id);
        if (error) Alert.alert("Delete failed", error.message);
        else {
          await supabase!.storage.from("study-resources").remove([item.storage_path]);
          setResources(old => old.filter(r => r.id !== item.id));
        }
      }}
    ]);
  }

  const visible = useMemo(() => resources.filter(r =>
    `${r.name} ${r.subject}`.toLowerCase().includes(search.toLowerCase())
  ), [resources, search]);

  const styles = makeStyles(c);
  return (
    <SafeAreaView style={styles.safe}>
      <ExpoStatusBar style={dark ? "light" : "dark"} />
      <StatusBar barStyle={dark ? "light-content" : "dark-content"} />
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <View style={styles.logo}><Text style={styles.logoText}>S</Text></View>
          <View><Text style={styles.brand}>StudyVault</Text><Text style={styles.tagline}>Your learning space</Text></View>
          <Pressable onPress={() => setMode(mode === "dark" ? "light" : "dark")} style={styles.themeButton}>
            <Text style={styles.themeText}>{dark ? "☀" : "☾"}</Text>
          </Pressable>
        </View>
        <Text style={styles.hero}>Your resources.{`\n`}One place.</Text>
        <Text style={styles.heroSub}>Keep your study materials organised and accessible.</Text>
      </View>

      {!configured ? (
        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>Connect your cloud storage</Text>
          <Text style={styles.muted}>Add your Supabase project URL and anon key to the local .env file. Follow README.md to configure Google sign-in and secure storage.</Text>
        </View>
      ) : !session ? (
        <View style={styles.centerCard}>
          <Text style={styles.emptyIcon}>☁</Text>
          <Text style={styles.cardTitle}>Your study library awaits</Text>
          <Text style={styles.muted}>Sign in with Google to keep your resources synced across devices.</Text>
          <Pressable style={styles.primaryButton} onPress={signIn}><Text style={styles.primaryText}>Continue with Google</Text></Pressable>
          <Text style={styles.tiny}>Google sign-in becomes active after the setup in README.md.</Text>
        </View>
      ) : (
        <View style={styles.content}>
          <View style={styles.stats}>
            <View><Text style={styles.statNumber}>{resources.length}</Text><Text style={styles.muted}>Resources</Text></View>
            <Text style={styles.cloud}>☁  Cloud synced</Text>
          </View>
          <Text style={styles.sectionTitle}>Add a resource</Text>
          <TextInput value={subject} onChangeText={setSubject} placeholder="Subject (e.g. Physics)" placeholderTextColor={c.muted} style={styles.input} />
          <Pressable disabled={busy} onPress={upload} style={[styles.primaryButton, busy && { opacity: 0.6 }]}>
            {busy ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.primaryText}>＋  Upload a file</Text>}
          </Pressable>
          <Text style={styles.sectionTitle}>My library</Text>
          <TextInput value={search} onChangeText={setSearch} placeholder="Search files or subjects" placeholderTextColor={c.muted} style={styles.input} />
          {loading ? <ActivityIndicator color={c.accent} /> : (
            <FlatList data={visible} keyExtractor={item => item.id} contentContainerStyle={{ paddingBottom: 28 }}
              ListEmptyComponent={<Text style={styles.muted}>No resources yet. Upload your first study file.</Text>}
              renderItem={({ item }) => (
                <Pressable onPress={() => openResource(item)} onLongPress={() => deleteResource(item)} style={styles.resource}>
                  <Text style={styles.fileIcon}>▤</Text>
                  <View style={{ flex: 1 }}><Text style={styles.resourceName} numberOfLines={1}>{item.name}</Text><Text style={styles.muted}>{item.subject}</Text></View>
                  <Text style={styles.muted}>⋯</Text>
                </Pressable>
              )}
            />
          )}
          <Pressable onPress={() => supabase?.auth.signOut()} style={styles.signOut}><Text style={styles.muted}>Sign out</Text></Pressable>
        </View>
      )}
      <View style={styles.footer}><Text style={styles.footerText}>STUDYVAULT  •  VERSION 1.0</Text></View>
    </SafeAreaView>
  );
}

function makeStyles(c: typeof palette.light) {
  return StyleSheet.create({
    safe: { flex: 1, backgroundColor: c.bg },
    header: { backgroundColor: darken(c.card), paddingHorizontal: 24, paddingTop: 22, paddingBottom: 28, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 },
    brandRow: { flexDirection: "row", alignItems: "center", gap: 12 },
    logo: { width: 42, height: 42, borderRadius: 14, backgroundColor: c.accent, alignItems: "center", justifyContent: "center" },
    logoText: { color: "#FFFFFF", fontWeight: "900", fontSize: 22 },
    brand: { color: c.text, fontWeight: "800", fontSize: 20 },
    tagline: { color: c.muted, fontSize: 12, marginTop: 2 },
    themeButton: { marginLeft: "auto", padding: 10, borderRadius: 12, backgroundColor: c.soft },
    themeText: { color: c.text, fontSize: 19 },
    hero: { color: c.text, fontSize: 32, fontWeight: "900", marginTop: 30, lineHeight: 38 },
    heroSub: { color: c.muted, fontSize: 14, marginTop: 9, lineHeight: 21 },
    content: { flex: 1, paddingHorizontal: 20, paddingTop: 22 },
    stats: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: c.card, borderColor: c.line, borderWidth: 1, padding: 18, borderRadius: 18, marginBottom: 22 },
    statNumber: { color: c.text, fontWeight: "900", fontSize: 28 },
    cloud: { color: c.accent, fontWeight: "700", fontSize: 12 },
    sectionTitle: { color: c.text, fontSize: 17, fontWeight: "800", marginBottom: 10, marginTop: 12 },
    input: { backgroundColor: c.card, borderWidth: 1, borderColor: c.line, color: c.text, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 13, marginBottom: 10 },
    primaryButton: { backgroundColor: c.accent, padding: 15, borderRadius: 14, alignItems: "center", marginTop: 5, marginBottom: 14 },
    primaryText: { color: "#FFFFFF", fontWeight: "800", fontSize: 15 },
    resource: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: c.card, borderWidth: 1, borderColor: c.line, borderRadius: 14, padding: 14, marginBottom: 9 },
    fileIcon: { fontSize: 23, color: c.accent },
    resourceName: { color: c.text, fontWeight: "700", fontSize: 14, maxWidth: 230 },
    muted: { color: c.muted, fontSize: 12, lineHeight: 18 },
    signOut: { padding: 12, alignItems: "center" },
    centerCard: { margin: 20, marginTop: 32, padding: 24, borderRadius: 22, backgroundColor: c.card, borderColor: c.line, borderWidth: 1, alignItems: "center" },
    emptyIcon: { fontSize: 40, color: c.accent, marginBottom: 12 },
    cardTitle: { color: c.text, fontWeight: "800", fontSize: 18, marginBottom: 8 },
    tiny: { color: c.muted, fontSize: 10, textAlign: "center", marginTop: 5 },
    notice: { margin: 20, padding: 20, backgroundColor: c.card, borderRadius: 18, borderColor: c.line, borderWidth: 1 },
    noticeTitle: { color: c.text, fontSize: 17, fontWeight: "800", marginBottom: 8 },
    footer: { padding: 12, alignItems: "center" },
    footerText: { color: c.muted, fontSize: 9, letterSpacing: 1.4, fontWeight: "700" }
  });
}
function darken(_c: any) { return _c; }
